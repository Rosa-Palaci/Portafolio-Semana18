from random import choice
from time import time
import random
import math
import statistics
import stat
import sys 
import time
import random as rm
import math as mt

# Evaluación 
puntos_aritmética=0
puntos_geometría=0
puntos_probabilidad=0
puntos_algebra=0
puntos_finales=0
area=''
while area != '5':
    print("------------------------------------------------------------------------------------------------------------------------------------")
    print("Bienvenido al repaso de estudio para el PISA. Este es el repaso de matemáticas. A continuación te mostramos las areas a estudiar:")
    print("\n")
    print("1)Aritmética\n2)Geometría\n3)Probabilidad\n4)Algebra\n5)Salir")
    print("\n")
    area = (input("Escribe la materia que quieres estudiar: "))
    print("------------------------------------------------------------------------------------------------------------------------------------")
    if area == "1": #Aritmética
        
        print ("A continuación se desplegará el cuestionario de Aritmética: ")
        a = rm.randint(1,20)
        b = rm.randint(1,20)
        c = rm.randint(1,20)
        d = rm.randint(1,20)
        e = rm.randint(1,20)
        g = rm.randint(1,20)
        pr_art1 =(f"Cuanto es {a}+{b}+{c}?")
        pr_art2 =(f"Cuanto es {a}+{b}·({c}+{d})-{b}·{a}+{c}?")
        pr_art3 =(f"Cuanto es ({c}+{d})·({e}·{a})-{c}·{d}+{b}?")
        pr_art4 =(f"Cuanto es {a}^2+{c}^2?")
        pr_art5 =(f"Cuanto es ({c}+{d}·{a})/{e}?")
        pr_art6 =(f"Cuanto es {a}^2+{c}·2-{d}·2?")
        pr_art7 =(f"Cuanto es ({a}+{b})-({d}·{e})+{c}^2?")
        pr_art8 =(f"Cuanto es la raiz de √{g}?")
        pr_art9 =(f"Cuanto es {a}·({b}-({c}·{b}))+{g}·{a}?")
        pr_art10 =(f"Cuanto es {g}·{d}+ √{g}-{e}^2?")
        pr_art11 =(f"Cuanto es √{b} + {c}^2 +(√{d}+{g})?")
        pr_art12 =(f"Cuanto es la raiz de {b}^4?")
        pr_art13 =(f"Cuanto es ({a} +({b}/{d}))/{g}?")
        r_art1 = a+b+c
        r_art2 = a+b*(c+d)-b*a+c
        r_art3 = (c+d)*(e*a)-c*d+b
        r_art4 = a**2 +c**2
        r_art5 = round((c+d*a)/(e),2)
        r_art6 = a**2 +c*2-d*2
        r_art7 = (a+b)-(d*e)+c**2
        r_art8 = round(mt.sqrt(g),2)
        r_art9 = a*(b-(c*b))+g*a
        r_art10 = round(g*d+(mt.sqrt(g))-e**2,2)
        r_art11 = round((round(b**(1/2),2))+c**2+(round((d+g)**(1/2),2)),2)
        r_art12 = round(mt.sqrt(b**4))
        r_art13 = round((a+(b/d))/g,2)
            #-----------------------------------------------------------------------------------------
        preguntas_arit =[pr_art1,pr_art2,pr_art3,pr_art4,pr_art5,pr_art6,pr_art7,pr_art8,pr_art9,pr_art10,pr_art11,pr_art12,pr_art13]
        resp_arit =[r_art1,r_art2,r_art3,r_art4,r_art5,r_art6,r_art7,r_art8,r_art9,r_art10,r_art11,r_art12,r_art13]
            #----------------------------------------------------------------------------------------
        def pregunta_calif(pregunta,resp_cor,marcador):
      
            print(pregunta)
            resp = float(input('Respuesta: '))
            if resp == resp_cor:
                
                print('¡Correcto!')
                marcador += 1
                print(f"Tu puntaje actual es de {marcador}\n")
                return marcador
                
            else:
                print(f"Respuesta errónea, respuesta correcta {resp_cor}")
                print(f"Tu puntaje actual es de {marcador}\n")
                return marcador
        print("En las respuestas que se necesite, ¡SOLO AGREGA 2 DECIMALES!\nDe igual manera solo usa dos decimales en la raices\nSi es necesario tambien redondea tu segunda decimal\nPor ejemplo: si tu resultado es 3.358, redondea a 3.36\n")
        marc = 0
        for veces in range(13):
            
            pregArt = rm.choice(preguntas_arit)
            indice_preg = preguntas_arit.index(pregArt)
            marc=pregunta_calif(pregArt, resp_arit[indice_preg],marc)
            preguntas_arit.remove(pregArt)
            del resp_arit[indice_preg]
        puntos_aritmética=marc 
    elif area == "2": #Geometría
        print ("A continuación se desplegará el cuestionario de Geometría: ")
        print ("\n")
        print ("Calcula mediante la formula de Herón el area del triangulo")
        for veces in range (6):
            while True:
                a1= random.randint(1,20)
                b1= random.randint(1,20)
                c1= random.randint(1,20)
                if a1+b1>c1 and b1+c1>a1 and a1+c1>b1:
                    break
            print(f"El lado a mide {a1}")
            print(f"El lado b mide {b1}")
            print(f"El lado c mide {c1}")
            s= (a1+b1+c1)/2
            A= s*(s-a1)*(s-b1)*(s-c1)
            rA=math.sqrt(A)
            print("Cual es el area?")
            print ("\n")
            respuesta1= float(input(f"Tu respuesta es (escribela con 2 decimales): "))
            if respuesta1 == round(rA,2):
                puntos_geometría += 1
                print ("¡Correcto!")
                print ("Puntaje actual: ", puntos_geometría)
                print ("\n")
            else:
                print(f"Respuesta errónea, respuesta correcta {rA}")
                print ("Puntaje actual: ", puntos_geometría)
                print ("\n")
        print("--------------------------------------------------------------------------------------------------------")
        print("Siguiente bloque\n")
        print("Calcula la hipotenusa usando el Teorema de pitágoras")
        print ("\n")
        for veces in range (6):
            a= random.randint(10,50)
            b= random.randint(10,50)
            print(f"El lado a mide {a}")
            print(f"El lado a mide {b}")
            hipotenusa=math.sqrt(a**2 + b**2)
            print ("\n")
            print("Cual es la hipotenusa?")
            respuesta= float(input(f"Tu respuesta es (escribela con 2 decimales): "))
            if respuesta == round(hipotenusa,2):
                puntos_geometría += 1
                print ("¡Correcto!")
                print ("Puntaje actual: ", puntos_geometría)
                print ("\n")
            else:
                print(f"Respuesta errónea, respuesta correcta {hipotenusa}")
                print ("Puntaje actual: ", puntos_geometría)
                print ("\n")
        print("El cuestionario de Geometría ha terminado, gracias por estudiar para el PISA")
    elif area == "3": #Probabilidad
        print("------------------------------------------------------------------------------------------------------------------------------------")
        print("Calcula el promedio de estos numeros")
        for veces in range (4):
            print("Los numeros son:")
            numeros1= random.randint(1,20)
            numeros2= random.randint(1,20)
            numeros3= random.randint(1,20)
            numeros4= random.randint(1,20)
            numeros5= random.randint(1,20)
            numeros6= random.randint(1,20)
            numeros7= random.randint(1,20)
            numeros8= random.randint(1,20)
            numeros9= random.randint(1,20)
            numeros10= random.randint(1,20)
            print (numeros1, numeros2, numeros3, numeros4, numeros5, numeros6, numeros7, numeros8, numeros9, numeros10)
            numeros= (numeros1, numeros2, numeros3, numeros4, numeros5, numeros6, numeros7, numeros8, numeros9, numeros10)
            respuesta_correcta=(numeros1+numeros2+numeros3+numeros4+numeros5+numeros6+numeros7+numeros8+numeros9+numeros10) / 10
            print ("\n")
            respuesta4= float(input(f"Tu respuesta es: "))
            if respuesta4 == round(respuesta_correcta,2):
                puntos_probabilidad += 1
                print ("¡Correcto!")
                print ("Puntaje actual: ", puntos_probabilidad)
                print ("\n")
            else:
                print(f"Respuesta errónea, respuesta correcta {respuesta_correcta}")
                print ("Puntaje actual: ", puntos_probabilidad)
                print ("\n")
        print("------------------------------------------------------------------------------------------------------------------------------------")
        print("Calcula la mediana de los numeros")
        for veces in range (4):
            print("Los numeros son:")
            numeros_1= random.randint(1,20)
            numeros_2= random.randint(1,20)
            numeros_3= random.randint(1,20)
            numeros_4= random.randint(1,20)
            numeros_5= random.randint(1,20)
            numeros_6= random.randint(1,20)
            numeros_7= random.randint(1,20)
            numeros_8= random.randint(1,20)
            numeros_9= random.randint(1,20)
            numeros_10= random.randint(1,20)
            print (numeros_1, numeros_2, numeros_3, numeros_4, numeros_5, numeros_6, numeros_7, numeros_8, numeros_9, numeros_10)
            numeros_lista=(numeros_1, numeros_2, numeros_3, numeros_4, numeros_5, numeros_6, numeros_7, numeros_8, numeros_9, numeros_10)
            respuesta_correcta_2= statistics.median(numeros_lista)
            respuesta4= float(input(f"Tu respuesta es: "))
            if respuesta4 == round(respuesta_correcta_2,2):
                puntos_probabilidad += 1
                print ("¡Correcto!")
                print ("Puntaje actual: ", puntos_probabilidad)
                print ("\n")
            else:
                print(f"Respuesta errónea, respuesta correcta {respuesta_correcta_2}")
                print ("Puntaje actual: ", puntos_probabilidad)
                print ("\n")
        print("------------------------------------------------------------------------------------------------------------------------------------")
        print("Calcula la moda \nSi hay dos numeros que consideras moda escribe el primer numero que se repita, si no se repite ninguno escribe el primer numero")
        for veces in range (4):
            print("Los numeros son:")
            numeros_11= random.randint(1,20)
            numeros_12= random.randint(1,20)
            numeros_13= random.randint(1,20)
            numeros_14= random.randint(1,20)
            numeros_15= random.randint(1,20)
            numeros_16= random.randint(1,20)
            numeros_17= random.randint(1,20)
            numeros_18= random.randint(1,20)
            numeros_19= random.randint(1,20)
            numeros_20= random.randint(1,20)
            print (numeros_11, numeros_12, numeros_13, numeros_14, numeros_15, numeros_16, numeros_17, numeros_18, numeros_19, numeros_20)
            numeros_lista_2=(numeros_11, numeros_12, numeros_13, numeros_14, numeros_15, numeros_16, numeros_17, numeros_18, numeros_19, numeros_20)
            respuesta_correcta_3= statistics.mode(numeros_lista_2)
            respuesta5= float(input(f"Tu respuesta es: "))
            if respuesta5 == round(respuesta_correcta_3,2):
                puntos_probabilidad += 1
                print ("¡Correcto!")
                print ("Puntaje actual: ", puntos_probabilidad)
                print ("\n")
            else:
                print(f"Respuesta errónea, respuesta correcta {respuesta_correcta_3}")
                print ("Puntaje actual: ", puntos_probabilidad)
                print ("\n")
        print("El cuestionario de Probabilidad ha terminado, gracias por estudiar para el PISA")
    elif area == "4": #Algebra
        print ("A continuación se desplegará el cuestionario de Algebra: ")
        print ("\n")
        pregunta1= print("La suma de cinco veces X y seis veces Y es:")
        a = print("a)5y + 6x")
        b = print("b)x+x+x+x+x+y+y+y+y+y+y")
        c = print("c)5x + 6y")# respuesta correcta        
        d = print("d)5(X)-6(y)")
        print ("\n")
        respuesta_1= (input("Cual es el inciso correcto?: "))
        print ("\n")
        if respuesta_1 == "c":
            puntos_algebra += 1
            print ("¡Correcto!")
            print ("Puntaje actual: ", puntos_algebra)
            print ("\n")
        else:
            print("Respuesta errónea, respuesta correcta: inciso c)")
            print ("Puntaje actual: ", puntos_algebra)
            print ("\n")
        pregunta2= print("El perímetro P de un rectángulo es igual al doble de la suma de su songitud L y su anchura A")
        print ("\n")
        a = print("a)P=2L+A")
        b = print("b)P=L+2A")
        c = print("c)P=4L+4A")
        d = print("d)P=2(L+A)")# respuesta correcta
        print ("\n")
        respuesta_2= (input("Cual es el inciso correcto?: "))
        print ("\n")
        if respuesta_2 == "d":
            puntos_algebra += 1
            print ("¡Correcto!")
            print ("Puntaje actual: ", puntos_algebra)
            print ("\n")
        else:
            print("Respuesta errónea, respuesta correcta: inciso d)")
            print ("Puntaje actual: ", puntos_algebra)
            print ("\n")
        pregunta3= print("B más el producto de O y U")
        print ("\n")
        a = print("a)B+1(OOU)")
        b = print("b)B-(O+U)")
        c = print("c)B+OU")# respuesta correcta
        d = print("d)B + (O)+(U)")
        print ("\n")
        respuesta_3= (input("Cual es el inciso correcto?: "))
        print ("\n")
        if respuesta_3 == "c":
            puntos_algebra += 1
            print ("¡Correcto!")
            print ("Puntaje actual: ", puntos_algebra)
            print ("\n")
        else:
            print("Respuesta errónea, respuesta correcta: inciso c)")
            print ("Puntaje actual: ", puntos_algebra)
            print ("\n")
        pregunta4= print("Resuelve para v")
        print ("\n")
        a = print("a) v=24+(3b*3)")# respuesta correcta
        b = print("b) v=72b")
        c = print("c) v=216b")
        d = print("d) v=72+(3b)")
        print ("\n")
        respuesta_4= (input("Cual es el inciso correcto?: "))
        print ("\n")
        if respuesta_4 == "a":
            puntos_algebra += 1
            print ("¡Correcto!")
            print ("Puntaje actual: ", puntos_algebra)
            print ("\n")
        else:
            print("Respuesta errónea, respuesta correcta: inciso a)")
            print ("Puntaje actual: ", puntos_algebra)
            print ("\n")
        pregunta5= print("Resuelve para x")
        print ("\n")
        a = print("a) x=72")
        b = print("b) x=18")# respuesta correcta
        c = print("c) x=1.88")
        d = print("d) x=12(4/6)")
        print ("\n")
        respuesta_5= (input("Cual es el inciso correcto?: "))
        print ("\n")
        if respuesta_5 == "b":
            puntos_algebra += 1
            print ("¡Correcto!")
            print ("Puntaje actual: ", puntos_algebra)
            print ("\n")
        else:
            print("Respuesta errónea, respuesta correcta: inciso b)")
            print ("Puntaje actual: ", puntos_algebra)
            print ("\n")
        pregunta6= print(" multiplica (x**2+2x) por (x-5)")
        print ("\n")
        a = print("a) x**2-(6x**2)-(5x) ")
        b = print("b) x**3-(3x**2)-(10x)")# respuesta correcta
        c = print("c) y**3-(3y**2)-(10y)")
        d = print("d) x**2-(6x**3)-(12x)")
        print ("\n")
        respuesta_6= (input("Cual es el inciso correcto?: "))
        print ("\n")
        if respuesta_6 == "b":
            puntos_algebra += 1
            print ("¡Correcto!")
            print ("Puntaje actual: ", puntos_algebra)
            print ("\n")
        else:
            print("Respuesta errónea, respuesta correcta: inciso b)")
            print ("Puntaje actual: ", puntos_algebra)
            print ("\n")
        pregunta7= print("La gráfica que corresponda a: -13 < x y x<2")
        print ("\n")
        a = print("a) <---- +26 punto cerrado   punto abierto 2----->")
        b = print("b) <---- -13 punto cerrado   punto abierto 2----->")# respuesta correcta
        c = print("c) <---- -26 punto cerrado   punto abierto -2----->")
        d = print("d) <---- +13 punto cerrado   punto abierto -2----->")
        print ("\n")
        respuesta_7= (input("Cual es el inciso correcto?: "))
        print ("\n")
        if respuesta_7 == "b":
            puntos_algebra += 1
            print ("¡Correcto!")
            print ("Puntaje actual: ", puntos_algebra)
            print ("\n")
        else:
            print("Respuesta errónea, respuesta correcta: inciso b)")
            print ("Puntaje actual: ", puntos_algebra)
            print ("\n")
        pregunta8= print("La gráfica que corresponda a: -2 < x y x<4")
        print ("\n")
        a = print("a) <---- -8 punto cerrado  punto abierto +4 ------>")
        b = print("b) <---- +2 punto cerrado  punto abierto -4 ------>")
        c = print("c) <---- -2 punto cerrado  punto abierto +4 ------>")# respuesta correcta
        d = print("d) <---- -4 punto cerrado  punto abierto +2 ------>")
        print ("\n")
        respuesta_8= (input("Cual es el inciso correcto?: "))
        print ("\n")
        if respuesta_8 == "c":
            puntos_algebra += 1
            print ("¡Correcto!")
            print ("Puntaje actual: ", puntos_algebra)
            print ("\n")
        else:
            print("Respuesta errónea, respuesta correcta: inciso c)")
            print ("Puntaje actual: ", puntos_algebra)
            print ("\n")
        pregunta9= print("Calcula el punto del vértice de la función : f(x)= -2x**2 + 3x")
        print ("\n")
        a = print("a) (8/4,16/8)")
        b = print("b) (2/4,18/16)")
        c = print("c) (1/3,8/9)")
        d = print("d) (3/4,9/8)")# respuesta correcta
        print ("\n")
        respuesta_9= (input("Cual es el inciso correcto?: "))
        print ("\n")
        if respuesta_9 == "d":
            puntos_algebra += 1
            print ("¡Correcto!")
            print ("Puntaje actual: ", puntos_algebra)
            print ("\n")
        else:
            print("Respuesta errónea, respuesta correcta: inciso d)")
            print ("Puntaje actual: ", puntos_algebra)
            print ("\n")
        pregunta10= print("Divide{(6**5)+(x**4)+(4x**2)-(7x)+1} entre {(2x**2)+(x)-(3) el cociente es igual a:")
        print ("\n")
        a = print("a) (3x**3)-(x**2)+5x-2")# respuesta correcta
        b = print("b) (3x**2)-(x**3)+5x-5 ")
        c = print("c) (x**2)-(3x**3)+10x-2 ")
        d = print("d) (x**3)-(3x**2)+10x-5 ")
        print ("\n")
        respuesta_10= (input("Divide{(6**5)+(x**4)+(4x**2)-(7x)+1} entre {(2x**2)+(x)-(3) el cociente es igual a:"))
        print ("\n")
        if respuesta_10 == "a":
            puntos_algebra += 1
            print ("¡Correcto!")
            print ("Puntaje actual: ", puntos_algebra)
            print ("\n")
        else:
            print("Respuesta errónea, respuesta correcta: inciso a)")
            print ("Puntaje actual: ", puntos_algebra)
            print ("\n")
        pregunta11= print("Dividir {10x**5-(4x**a)+(8x**3)+(6x**2)-(5x)+11 // (2x**2)-(2x)+4")
        print ("\n")
        a = print("a) 30")# respuesta correcta
        b = print("b) 33")
        c = print("c) 23")
        d = print("d) 39")
        print ("\n")
        respuesta_11= (input("Cual es el inciso correcto?: "))
        print ("\n")
        if respuesta_11 == "a":
            puntos_algebra += 1
            print ("¡Correcto!")
            print ("Puntaje actual: ", puntos_algebra)
            print ("\n")
        else:
            print("Respuesta errónea, respuesta correcta: inciso a)")
            print ("Puntaje actual: ", puntos_algebra)
            print ("\n")
        pregunta12= print("Racionalizar: {4raiz(x)-6} / {2raiz(3x)}")
        print ("\n")
        a = print("a) {3x raiz (6) - 3raiz(6x)} / {2x} ")
        b = print("b) {3x raiz (3) - 3raiz(6x)} / {2x} ")
        c = print("c) {2x raiz (3) - 3raiz(3x)} / {3x} ")# respuesta correcta
        d = print("d) {2x raiz (6) - 3raiz(3x)} / {3x} ")
        print ("\n")
        respuesta_12= (input("Cual es el inciso correcto?: "))
        print ("\n")
        if respuesta_12 == "c":
            puntos_algebra += 1
            print ("¡Correcto!")
            print ("Puntaje actual: ", puntos_algebra)
            print ("\n")
        else:
            print("Respuesta errónea, respuesta correcta: inciso c)")
            print ("Puntaje actual: ", puntos_algebra)
            print ("\n")
        pregunta13= print("Racionalizar el denominador y simplificar la expresión: {4raiz(2)} / {3raiz(xy**2)}")
        a = print("a) {9 raiz (8x**2 y**2)} / {xy**4} ")
        b = print("b) {18 raiz (8xy**8)} / {x**2y**2} ")
        c = print("c) {9 raiz (4x**4 y**8)} / {xy**2} ")
        d = print("d) {18 raiz (8x**8 y**16)} / {xy**2} ")# respuesta correcta
        print ("\n")
        respuesta_13= (input("Cual es el inciso correcto?: "))
        print ("\n")
        if respuesta_13 == "d":
            puntos_algebra += 1
            print ("¡Correcto!")
            print ("Puntaje actual: ", puntos_algebra)
            print ("\n")
        else:
            print("Respuesta errónea, respuesta correcta: inciso d)")
            print ("Puntaje actual: ", puntos_algebra)
            print ("\n")
        print("El cuestionario de Algebra ha terminado, gracias por estudiar para el PISA")
    elif area == "5": #Salir
        print("Gracias por hacer nuestro cuestionario")
    else:
        print("Respuesta invalida ")

puntos_finales = puntos_aritmética+puntos_geometría+puntos_probabilidad+puntos_algebra
print(f"La preguntas que sacaste correctas fueron {puntos_finales} de 50 ")
print("El cuestionario de Matemáticas ha terminado, gracias por estudiar para el PISA")

nom_arch= "Reporte.txt"
arch= open(nom_arch,"w")
arch.write("Tus resultados finales han sido los siguientes\n")

arch.write(f"Prueba:\nAritmetica: {puntos_aritmética} preguntas correctas\nAlgebra: {puntos_algebra} preguntas correctas\nGeometria: {puntos_geometría} preguntas correctas\nProbabilidad: {puntos_probabilidad} preguntas correctas")
arch.write(f"\nTu puntaje final fue de {puntos_finales} preguntas correctas de 50 preguntas")
arch.write(f"\nCalificación final: {puntos_finales*2}\n")


arch.close()